package knitwear2;


import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class DateWiseProductionReportSearch extends javax.swing.JFrame {

    int tableSize = 0;

    public DateWiseProductionReportSearch() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        totalLabel = new javax.swing.JLabel();
        totalIncomeLabel = new javax.swing.JLabel();
        dateComboBox = new javax.swing.JComboBox<>();
        showButton = new javax.swing.JButton();
        monthComboBox = new javax.swing.JComboBox<>();
        yearComboBox = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        detailsTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(54, 18, 46));
        jPanel2.setForeground(new java.awt.Color(54, 18, 46));

        jLabel1.setBackground(new java.awt.Color(54, 18, 46));
        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Search Your Report");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE)
        );

        totalLabel.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        totalLabel.setForeground(new java.awt.Color(54, 18, 46));
        totalLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        totalLabel.setText("Total");

        totalIncomeLabel.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        totalIncomeLabel.setForeground(new java.awt.Color(54, 18, 46));
        totalIncomeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        for (int i=1; i<32; i++){
            dateComboBox.addItem(new Integer(i).toString());
        }
        dateComboBox.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N

        showButton.setFont(new java.awt.Font("Comic Sans MS", 1, 48)); // NOI18N
        showButton.setForeground(new java.awt.Color(54, 18, 46));
        showButton.setText("See Details");
        showButton.setRolloverEnabled(false);
        showButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showButtonActionPerformed(evt);
            }
        });

        for (int i=1; i<13; i++){
            monthComboBox.addItem(new Integer(i).toString());
        }
        monthComboBox.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N

        for (int i=2018; i<3001; i++){
            yearComboBox.addItem(new Integer(i).toString());
        }
        yearComboBox.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N

        detailsTable.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        detailsTable.setForeground(new java.awt.Color(54, 18, 46));
        detailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Style", "Total Production", "Daily Income"
            }
        ));
        detailsTable.setRowHeight(24);
        jScrollPane1.setViewportView(detailsTable);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(148, 148, 148)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(dateComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addComponent(monthComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(91, 91, 91)
                        .addComponent(yearComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(259, 259, 259)
                        .addComponent(showButton, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)))
                .addGap(214, 214, 214))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(totalLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(totalIncomeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(294, 294, 294))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(showButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(yearComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(dateComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(monthComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(61, 61, 61)
                .addComponent(jScrollPane1)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(totalLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(totalIncomeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(124, 124, 124))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void showButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showButtonActionPerformed

        DefaultTableModel table = (DefaultTableModel) detailsTable.getModel();
       

        //clear Table
        table.setRowCount(0);
        
        //Get date from the combo box
        int year = new Integer((yearComboBox.getSelectedItem().toString()));
        int month = new Integer(monthComboBox.getSelectedItem().toString());
        int day = new Integer(dateComboBox.getSelectedItem().toString());

        Date searchDate = new Date(year - 1900, month - 1, day);     //searchDate can be directly used for query

        Object[] rowData = new Object[3];

        
        ArrayList<DateWiseProductionReport> ar = new ArrayList<>();
        //Query by Anita
        ConnectDatabase obj = new ConnectDatabase();
        obj.connectDB();

        try {
            Statement statement = obj.connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select StyleNo,ProducedQuantity,Income from IncomeReport where SystemDate='"+searchDate+"'");
            DateWiseProductionReport x;
            while (resultSet.next()) {
                x = new DateWiseProductionReport(resultSet.getString("StyleNo"), resultSet.getInt("ProducedQuantity"),resultSet.getDouble("Income"));
                ar.add(x);
            }
        } catch (Exception e) {

        }
        
        double totalIncome = 0;

        int sz = ar.size();

        for (int i = 0; i < sz; i++) {
            //add data to the table
            rowData[0] = ar.get(i).styleNo;
            rowData[1] = ar.get(i).quantity;
            rowData[2] = ar.get(i).income;
            
            totalIncome+= ar.get(i).income;
            table.addRow(rowData);
        }

        totalIncomeLabel.setText(new Double(totalIncome).toString());
    }//GEN-LAST:event_showButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DateWiseProductionReportSearch().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> dateComboBox;
    private javax.swing.JTable detailsTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> monthComboBox;
    private javax.swing.JButton showButton;
    private javax.swing.JLabel totalIncomeLabel;
    private javax.swing.JLabel totalLabel;
    private javax.swing.JComboBox<String> yearComboBox;
    // End of variables declaration//GEN-END:variables
}
