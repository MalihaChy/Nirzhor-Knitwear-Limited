/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package knitwear2;

/**
 *
 * @author User
 */
public class DateWiseProductionReport {
        
    String styleNo;
    int quantity;
    double income;

    public DateWiseProductionReport() {
    }

    public DateWiseProductionReport(String styleNo, int quantity) {
        this.styleNo = styleNo;
        this.quantity = quantity;
        
    }

    public DateWiseProductionReport(String styleNo, int quantity, double income) {
        this.styleNo = styleNo;
        this.quantity = quantity;
        this.income = income;
    }
    
    
    
}
