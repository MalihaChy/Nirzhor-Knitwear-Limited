package knitwear2;


import java.sql.Date;

public class LineProductionInput {
    Date Date;
    String StyleNo;
    int	Line_No;
    int StartTime;
    int	EndTime;
    int	ProducedQuantity;

    public LineProductionInput() {
    }
   

    public LineProductionInput(Date Date, String StyleNo, int Line_No, int StartTime, int EndTime, int ProducedQuantity) {
        this.Date = Date;
        this.StyleNo = StyleNo;
        this.Line_No = Line_No;
        this.StartTime = StartTime;
        this.EndTime = EndTime;
        this.ProducedQuantity = ProducedQuantity;
    }
    
    

}
