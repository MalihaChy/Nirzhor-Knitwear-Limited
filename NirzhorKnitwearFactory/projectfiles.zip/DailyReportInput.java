package knitwear2;

import java.awt.Color;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Sujoy
 */
public class DailyReportInput extends javax.swing.JFrame {

    public static LocalDate currentDate;
    private static boolean reportButtonPressed;

    /**
     * Creates new form skeleton
     */
    public DailyReportInput() {
        initComponents();

        //Work related to date and time;
        todayDateLabel.setText(Knitwear2.currentDate.toString());
        hourCompleteButton.setBackground(Color.pink);
        if(reportButtonPressed){
            hourCompleteButton.setBackground(Color.green);
        }

    }

    public void PerLineProductionInput() {
        try {
            //take fixed date
            Date date = Date.valueOf(Knitwear2.currentDate);

            int startTime = new Integer(orderTimeCombobox.getSelectedItem().toString());
            int endTime = (startTime + 1) % 24;

            LineProductionInput x = new LineProductionInput(date, styleNoTextField.getText(), new Integer(lineComboBox.getSelectedItem().toString()).intValue(), startTime, endTime, new Integer(quantityTextField.getText()).intValue());

            ConnectDatabase obj = new ConnectDatabase();
            obj.connectDB();
            Statement statement = obj.connection.createStatement();
            statement.executeUpdate(" insert into DailyReportInput values "
                    + " ('" + x.Date + "','" + x.StyleNo + "'," + x.Line_No + "," + x.StartTime + "," + x.EndTime + "," + x.ProducedQuantity + ")");

        } catch (Exception e) {

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lineComboBox = new javax.swing.JComboBox();
        todayDateLabel = new javax.swing.JLabel();
        styleNoTextField = new javax.swing.JTextField();
        quantityTextField = new javax.swing.JTextField();
        reportButton = new javax.swing.JButton();
        orderTimelabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        styleTable = new javax.swing.JTable();
        orderTimeCombobox = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        hourCompleteButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(54, 18, 46));
        jPanel1.setPreferredSize(new java.awt.Dimension(1305, 110));

        jLabel7.setBackground(new java.awt.Color(54, 18, 46));
        jLabel7.setFont(new java.awt.Font("Comic Sans MS", 1, 48)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("     Report Orders");

        jLabel2.setText("jLabel2");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 1338, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(1390, 480));

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(54, 18, 46));
        jLabel1.setText("Today's Date");

        jLabel3.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(54, 18, 46));
        jLabel3.setText("Style No.");

        jLabel4.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(54, 18, 46));
        jLabel4.setText("Quantity");

        jLabel6.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(54, 18, 46));
        jLabel6.setText("Line No.");

        jLabel8.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(54, 18, 46));
        jLabel8.setText("Order Time");

        lineComboBox.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        try{
            ConnectDatabase obj = new ConnectDatabase();
            obj.connectDB();
            Statement statement = obj.connection.createStatement();
            ResultSet resultset = statement.executeQuery("select Line_No from LineTable where LineStatus='Not Used'");

            ArrayList<Integer> ar = new ArrayList<Integer>();
            int x;
            while(resultset.next())
            {
                x=new Integer(resultset.getString("Line_No"));
                System.out.println(x);
                ar.add(x);
            }
            int sz=ar.size();
            for(int i=0;i<sz;i++)lineComboBox.addItem(ar.get(i));
        }catch (Exception ex) {

        }
        lineComboBox.setMaximumRowCount(120120);

        todayDateLabel.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N

        styleNoTextField.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        styleNoTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                styleNoTextFieldKeyReleased(evt);
            }
        });

        quantityTextField.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        quantityTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quantityTextFieldActionPerformed(evt);
            }
        });

        reportButton.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        reportButton.setForeground(new java.awt.Color(54, 18, 46));
        reportButton.setText("Report");
        reportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportButtonActionPerformed(evt);
            }
        });

        orderTimelabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N

        styleTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Style No"
            }
        ));
        styleTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                styleTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(styleTable);

        orderTimeCombobox.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        for(int i=0; i<24; i++){
            orderTimeCombobox.addItem(new Integer(i).toString());
        }
        orderTimeCombobox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                orderTimeComboboxItemStateChanged(evt);
            }
        });
        orderTimeCombobox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                orderTimeComboboxMouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Comic Sans MS", 1, 24)); // NOI18N
        jLabel9.setText("To");

        hourCompleteButton.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        hourCompleteButton.setText("Hour Complete");
        hourCompleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hourCompleteButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(1248, 1248, 1248))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lineComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(534, 534, 534)
                        .addComponent(reportButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(120, 120, 120)
                        .addComponent(hourCompleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(238, 238, 238))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(52, 52, 52)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(styleNoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(147, 147, 147)
                                        .addComponent(todayDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(84, 84, 84)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(58, 58, 58)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(orderTimeCombobox, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(49, 49, 49))
                            .addComponent(quantityTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addComponent(orderTimelabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(229, 229, 229))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(todayDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(85, 85, 85))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(81, 81, 81))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(orderTimelabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(orderTimeCombobox)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGap(81, 81, 81)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(quantityTextField)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(styleNoTextField)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(hourCompleteButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lineComboBox, javax.swing.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)
                    .addComponent(reportButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31))
        );

        jScrollPane2.setViewportView(jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 499, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void quantityTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quantityTextFieldActionPerformed


    }//GEN-LAST:event_quantityTextFieldActionPerformed

    private void styleTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_styleTableMouseClicked
        // TODO add your handling code here:
        styleNoTextField.setText(styleTable.getValueAt(styleTable.getSelectedRow(), 0).toString());
    }//GEN-LAST:event_styleTableMouseClicked

    private void styleNoTextFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_styleNoTextFieldKeyReleased
        // TODO add your handling code here:
        if (!styleNoTextField.getText().equalsIgnoreCase("")) {
            ArrayList<String> ar = new ArrayList<String>();
            DefaultTableModel table = (DefaultTableModel) styleTable.getModel();
            int rowCount = table.getRowCount();
            for (int i = 0; i < rowCount; i++) {
                table.removeRow(i);
            }

            try {
                ConnectDatabase obj = new ConnectDatabase();
                obj.connectDB();
                Statement statement = obj.connection.createStatement();

                ResultSet resultset = statement.executeQuery("select StyleNo from ProductionStatus where "
                        + " StyleNo like '%" + styleNoTextField.getText() + "%'");

                String x;

                while (resultset.next()) {
                    x = new String(resultset.getString("StyleNo"));
                    ar.add(x);
                }

            } catch (Exception ex) {

            }

            System.out.println(styleNoTextField.getText());
            //query;
            Object rowData[] = new Object[1];
            int sz = ar.size();
            for (int i = 0; i < sz; i++) {
                rowData[0] = ar.get(i);

                table.addRow(rowData);
            }

        }
    }//GEN-LAST:event_styleNoTextFieldKeyReleased

    private void reportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportButtonActionPerformed

        try {
            ConnectDatabase obj = new ConnectDatabase();
            obj.connectDB();
            Statement statement = obj.connection.createStatement();

            statement.executeUpdate("update LineTable set LineStatus='Used' where Line_No=" + new Integer(lineComboBox.getSelectedItem().toString()).intValue());

            PerLineProductionInput();

        } catch (Exception ex) {

        }
        reportButtonPressed = true;

        this.setVisible(false);
        new DailyReportInput().setVisible(true);


    }//GEN-LAST:event_reportButtonActionPerformed

    private void orderTimeComboboxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_orderTimeComboboxMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_orderTimeComboboxMouseClicked

    private void orderTimeComboboxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_orderTimeComboboxItemStateChanged
        // TODO add your handling code here:
        Integer endTime = (new Integer(orderTimeCombobox.getSelectedItem().toString()) + 1) % 24;
        orderTimelabel1.setText(endTime.toString());
    }//GEN-LAST:event_orderTimeComboboxItemStateChanged

    private void hourCompleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hourCompleteButtonActionPerformed
        if (reportButtonPressed) {
            try {
                ConnectDatabase obj = new ConnectDatabase();
                obj.connectDB();
                Statement statement = obj.connection.createStatement();

                statement.executeUpdate("update LineTable set LineStatus='Not Used'");

            } catch (Exception ex) {

            }
            hourCompleteButton.setBackground(Color.green);
            this.setVisible(false);
            new DailyReportInput().setVisible(true);
        }
    }//GEN-LAST:event_hourCompleteButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DailyReportInput.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DailyReportInput.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DailyReportInput.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DailyReportInput.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DailyReportInput().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton hourCompleteButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JComboBox lineComboBox;
    private javax.swing.JComboBox<String> orderTimeCombobox;
    private javax.swing.JLabel orderTimelabel1;
    private javax.swing.JTextField quantityTextField;
    private javax.swing.JButton reportButton;
    private javax.swing.JTextField styleNoTextField;
    private javax.swing.JTable styleTable;
    private javax.swing.JLabel todayDateLabel;
    // End of variables declaration//GEN-END:variables
}
